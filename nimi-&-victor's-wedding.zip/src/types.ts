export interface TimelineEvent {
  id: string;
  year: string;
  title: string;
  story: string;
  flowerType: 'rose' | 'blossom' | 'tulip' | 'lotus' | 'sunflower';
  color: string;
}

export interface RegistryItem {
  id: string;
  title: string;
  category: string;
  price: string;
  description: string;
  iconName: string;
  raised: number; // contribution percent or raw amount
}

export interface LoveNote {
  id: string;
  sender: string;
  relationship: string;
  message: string;
  date: string;
  response?: string;
}

export interface RsvpData {
  name: string;
  email: string;
  attending: 'yes' | 'no' | '';
  guestsCount: number;
  dietaryNotes: string;
  message: string;
}
