import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface OpeningExperienceProps {
  onComplete: () => void;
  isDark: boolean;
}

// Organic staggered timings and angles for each petal layer
const outerPetals = [
  { id: 'out-1', initialRotate: 0, delay: 2.1 },
  { id: 'out-2', initialRotate: 72, delay: 2.3 },
  { id: 'out-3', initialRotate: 144, delay: 2.5 },
  { id: 'out-4', initialRotate: 216, delay: 2.2 },
  { id: 'out-5', initialRotate: 288, delay: 2.4 },
];

const midPetals = [
  { id: 'mid-1', initialRotate: 36, delay: 1.6 },
  { id: 'mid-2', initialRotate: 108, delay: 1.8 },
  { id: 'mid-3', initialRotate: 180, delay: 2.0 },
  { id: 'mid-4', initialRotate: 252, delay: 1.7 },
  { id: 'mid-5', initialRotate: 324, delay: 1.9 },
];

const innerPetals = [
  { id: 'inn-1', initialRotate: 0, delay: 1.1 },
  { id: 'inn-2', initialRotate: 90, delay: 1.3 },
  { id: 'inn-3', initialRotate: 180, delay: 1.2 },
  { id: 'inn-4', initialRotate: 270, delay: 1.4 },
];

const corePetals = [
  { id: 'core-1', initialRotate: 45, delay: 0.7 },
  { id: 'core-2', initialRotate: 165, delay: 0.9 },
  { id: 'core-3', initialRotate: 285, delay: 0.8 },
];

// Motion variants simulating realistic organic growth & blooming phases
const petalVariants = {};

export default function OpeningExperience({ onComplete, isDark }: OpeningExperienceProps) {
  const [animationStep, setAnimationStep] = useState(0); // 0: growing/drawing, 1: blooming, 2: ready to enter

  useEffect(() => {
    // 1. Grow stem, sepals, and start bloom: 0 to 2.2 seconds
    const timer1 = setTimeout(() => {
      setAnimationStep(1);
    }, 2200);

    // 2. Unfurl outer layers completely and present "Enter" controls: 2.2 to 4.5 seconds
    const timer2 = setTimeout(() => {
      setAnimationStep(2);
    }, 4500);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  // Premium, luxury-minded dynamic outline color matching dark vs light themes
  const petalStroke = isDark ? "rgba(234, 216, 177, 0.35)" : "rgba(94, 3, 17, 0.28)";

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -20, filter: 'blur(10px)' }}
      transition={{ duration: 1.5, ease: [0.43, 0.13, 0.23, 0.96] }}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden transition-colors duration-1000 ${
        isDark ? 'bg-dark-garden' : 'bg-bloom-cream'
      }`}
    >
      {/* Background drifting slow petals */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        {Array.from({ length: 12 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `-10%`,
              width: `${15 + Math.random() * 20}px`,
              height: `${15 + Math.random() * 20}px`,
            }}
            animate={{
              y: ['0vh', '110vh'],
              x: ['0vw', `${(Math.sin(i) * 10).toFixed(1)}vw`],
              rotate: [0, 360],
            }}
            transition={{
              duration: 10 + Math.random() * 10,
              repeat: Infinity,
              ease: 'linear',
              delay: Math.random() * -5,
            }}
          >
            <svg viewBox="0 0 100 100" fill="currentColor" className="text-bloom-rose/30 dark:text-bloom-blush/20">
              <path d="M50 0 C75 25, 90 60, 50 100 C10 60, 25 25, 50 0" />
            </svg>
          </motion.div>
        ))}
      </div>

      {/* Center Cinematic Artpiece */}
      <div className="relative flex flex-col items-center max-w-lg px-6 text-center select-none">
        
        {/* Subtitle / Context */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.3 }}
          className={`font-serif tracking-[0.3em] uppercase text-xs mb-6 ${
            isDark ? 'text-bloom-gold-light/60' : 'text-bloom-sage-dark/80'
          }`}
        >
          Nimi & Victor
        </motion.p>

        {/* Cinematic Blooming Flower Drawing SVG */}
        <div className="relative w-64 h-64 md:w-80 md:h-80 my-4 flex items-center justify-center">
          
          {/* Circular frame background */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.05 }}
            transition={{ duration: 2.5, ease: 'easeOut' }}
            className={`absolute inset-0 rounded-full border-2 ${
              isDark ? 'border-bloom-gold' : 'border-bloom-sage'
            }`}
          />

          {/* SVG Flower Outline Drawing and Blooming */}
          <svg
            viewBox="0 0 200 200"
            className="w-full h-full relative z-10 filter drop-shadow-[0_8px_24px_rgba(0,0,0,0.06)] dark:drop-shadow-[0_8px_32px_rgba(0,0,0,0.3)]"
          >
            {/* Gradients definitions for photorealistic botanical luxury */}
            <defs>
              {/* Stem gradient */}
              <linearGradient id="stem-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#4A6B53" />
                <stop offset="100%" stopColor="#223326" />
              </linearGradient>

              {/* Leaf/Sepal gradient */}
              <linearGradient id="leaf-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#6E9B7B" />
                <stop offset="50%" stopColor="#4A6B53" />
                <stop offset="100%" stopColor="#1E3324" />
              </linearGradient>

              {/* Velvet red gradients of varying depth to give petals 3D texture */}
              <radialGradient id="rose-outer" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#E55562" />
                <stop offset="55%" stopColor="#BA1A2C" />
                <stop offset="100%" stopColor="#730813" />
              </radialGradient>

              <radialGradient id="rose-mid" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#F27282" />
                <stop offset="60%" stopColor="#C92035" />
                <stop offset="100%" stopColor="#820B18" />
              </radialGradient>

              <radialGradient id="rose-inner" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#FF9AA7" />
                <stop offset="65%" stopColor="#E6354D" />
                <stop offset="100%" stopColor="#960E1E" />
              </radialGradient>

              <radialGradient id="rose-core" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#FFC2CD" />
                <stop offset="45%" stopColor="#FF5C77" />
                <stop offset="85%" stopColor="#BA1430" />
                <stop offset="100%" stopColor="#4F010E" />
              </radialGradient>
              
              {/* Soft watercolor ambient background bloom glow */}
              <radialGradient id="rose-watercolor" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#E24A56" stopOpacity="0.45" />
                <stop offset="60%" stopColor="#D1263B" stopOpacity="0.12" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0" />
              </radialGradient>

              {/* Gold Shimmer Core stamen glow */}
              <radialGradient id="gold-shimmer-grad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#FFF2D1" />
                <stop offset="50%" stopColor="#E0B863" />
                <stop offset="100%" stopColor="#A88131" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Ambient background bloom glow */}
            <motion.circle
              cx="100"
              cy="105"
              r="75"
              fill="url(#rose-watercolor)"
              initial={{ scale: 0.1, opacity: 0 }}
              animate={{ 
                scale: animationStep === 0 ? 0.3 : animationStep === 1 ? 1 : [1, 1.05, 1],
                opacity: animationStep === 0 ? 0 : 0.9
              }}
              transition={{ 
                scale: { duration: 3.2, ease: "easeOut" },
                opacity: { duration: 2 },
                repeat: animationStep === 2 ? Infinity : 0,
                repeatType: "reverse"
              }}
              className="pointer-events-none"
            />

            {/* Stem grows upwards beautifully */}
            <motion.path
              d="M100 195 Q98 150, 100 105"
              fill="none"
              stroke="url(#stem-grad)"
              strokeWidth="3.5"
              strokeLinecap="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.8, ease: "easeInOut" }}
            />

            {/* Left Stem Leaf sprouting */}
            <motion.path
              d="M98 155 C80 155, 65 145, 75 135 C85 132, 92 142, 98 155"
              fill="url(#leaf-grad)"
              stroke="#2E4033"
              strokeWidth="0.75"
              style={{ transformOrigin: "98px 155px" }}
              initial={{ scale: 0, opacity: 0, rotate: 20 }}
              animate={{ 
                scale: animationStep >= 1 ? 1 : 0, 
                opacity: animationStep >= 1 ? 1 : 0,
                rotate: animationStep === 2 ? [0, 2, -2, 0] : 0
              }}
              transition={{ 
                scale: { delay: 0.8, duration: 1.2, ease: "easeOut" },
                opacity: { delay: 0.8, duration: 1.2 },
                rotate: { duration: 6, repeat: Infinity, ease: "easeInOut" }
              }}
            />

            {/* Right Stem Leaf sprouting */}
            <motion.path
              d="M102 140 C120 140, 135 130, 125 120 C115 117, 108 127, 102 140"
              fill="url(#leaf-grad)"
              stroke="#2E4033"
              strokeWidth="0.75"
              style={{ transformOrigin: "102px 140px" }}
              initial={{ scale: 0, opacity: 0, rotate: -20 }}
              animate={{ 
                scale: animationStep >= 1 ? 1 : 0, 
                opacity: animationStep >= 1 ? 1 : 0,
                rotate: animationStep === 2 ? [0, -2, 2, 0] : 0
              }}
              transition={{ 
                scale: { delay: 1.1, duration: 1.2, ease: "easeOut" },
                opacity: { delay: 1.1, duration: 1.2 },
                rotate: { duration: 5.5, repeat: Infinity, ease: "easeInOut" }
              }}
            />

            {/* Sepals supporting flower base (they peel back outwards as flower blooms) */}
            {/* Left Sepal */}
            <motion.path
              d="M100 105 C85 112, 70 115, 75 130 C82 122, 92 112, 100 105"
              fill="url(#leaf-grad)"
              stroke="#1E3324"
              strokeWidth="0.75"
              style={{ transformOrigin: "100px 105px" }}
              initial={{ scale: 0.5, rotate: 25, opacity: 0 }}
              animate={{ 
                scale: animationStep === 0 ? 0.7 : 1, 
                rotate: animationStep === 0 ? 10 : -15,
                opacity: 1
              }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />

            {/* Right Sepal */}
            <motion.path
              d="M100 105 C115 112, 130 115, 125 130 C118 122, 108 112, 100 105"
              fill="url(#leaf-grad)"
              stroke="#1E3324"
              strokeWidth="0.75"
              style={{ transformOrigin: "100px 105px" }}
              initial={{ scale: 0.5, rotate: -25, opacity: 0 }}
              animate={{ 
                scale: animationStep === 0 ? 0.7 : 1, 
                rotate: animationStep === 0 ? -10 : 15,
                opacity: 1
              }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />

            {/* Center Sepal */}
            <motion.path
              d="M100 105 C95 118, 90 125, 100 138 C110 125, 105 118, 100 105"
              fill="url(#leaf-grad)"
              stroke="#1E3324"
              strokeWidth="0.75"
              style={{ transformOrigin: "100px 105px" }}
              initial={{ scale: 0.4, opacity: 0 }}
              animate={{ 
                scale: animationStep === 0 ? 0.6 : 1,
                opacity: 1
              }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />

            {/* ROSE PETAL LAYERS - blooming from inside-out */}

            {/* LAYER 1: OUTER PETALS (Symmetrical layout wrapping the perimeter) */}
            {outerPetals.map((p) => (
              <motion.path
                key={p.id}
                d="M100 105 C65 75, 45 45, 100 20 C155 45, 135 75, 100 105"
                fill="url(#rose-outer)"
                stroke={petalStroke}
                strokeWidth="0.5"
                style={{ transformOrigin: "100px 105px" }}
                initial={{ scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }}
                animate={
                  animationStep === 0
                    ? { scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }
                    : animationStep === 1
                    ? { scale: 1.0, opacity: 1, rotate: p.initialRotate, y: 0 }
                    : {
                        scale: [1.0, 1.03, 1.0],
                        rotate: [p.initialRotate, p.initialRotate + 2, p.initialRotate - 2, p.initialRotate],
                        opacity: 1,
                        y: 0,
                      }
                }
                transition={
                  animationStep === 2
                    ? {
                        scale: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                        rotate: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                      }
                    : {
                        delay: p.delay,
                        duration: 2.8,
                        ease: [0.16, 1, 0.3, 1],
                      }
                }
              />
            ))}

            {/* LAYER 2: MIDDLE PETALS (Slightly smaller, offset to fill gaps) */}
            {midPetals.map((p) => (
              <motion.path
                key={p.id}
                d="M100 105 C70 80, 55 55, 100 32 C145 55, 130 80, 100 105"
                fill="url(#rose-mid)"
                stroke={petalStroke}
                strokeWidth="0.5"
                style={{ transformOrigin: "100px 105px" }}
                initial={{ scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }}
                animate={
                  animationStep === 0
                    ? { scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }
                    : animationStep === 1
                    ? { scale: 0.82, opacity: 1, rotate: p.initialRotate, y: 0 }
                    : {
                        scale: [0.82, 0.82 * 1.03, 0.82],
                        rotate: [p.initialRotate, p.initialRotate + 2, p.initialRotate - 2, p.initialRotate],
                        opacity: 1,
                        y: 0,
                      }
                }
                transition={
                  animationStep === 2
                    ? {
                        scale: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                        rotate: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                      }
                    : {
                        delay: p.delay,
                        duration: 2.8,
                        ease: [0.16, 1, 0.3, 1],
                      }
                }
              />
            ))}

            {/* LAYER 3: INNER PETALS (Tighter core overlay) */}
            {innerPetals.map((p) => (
              <motion.path
                key={p.id}
                d="M100 105 C75 85, 65 65, 100 45 C135 65, 125 85, 100 105"
                fill="url(#rose-inner)"
                stroke={petalStroke}
                strokeWidth="0.5"
                style={{ transformOrigin: "100px 105px" }}
                initial={{ scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }}
                animate={
                  animationStep === 0
                    ? { scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }
                    : animationStep === 1
                    ? { scale: 0.65, opacity: 1, rotate: p.initialRotate, y: 0 }
                    : {
                        scale: [0.65, 0.65 * 1.03, 0.65],
                        rotate: [p.initialRotate, p.initialRotate + 2, p.initialRotate - 2, p.initialRotate],
                        opacity: 1,
                        y: 0,
                      }
                }
                transition={
                  animationStep === 2
                    ? {
                        scale: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                        rotate: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                      }
                    : {
                        delay: p.delay,
                        duration: 2.8,
                        ease: [0.16, 1, 0.3, 1],
                      }
                }
              />
            ))}

            {/* LAYER 4: CORE PETALS (Deepest heart of the bud) */}
            {corePetals.map((p) => (
              <motion.path
                key={p.id}
                d="M100 105 C80 90, 75 75, 100 58 C125 75, 120 90, 100 105"
                fill="url(#rose-core)"
                stroke={petalStroke}
                strokeWidth="0.5"
                style={{ transformOrigin: "100px 105px" }}
                initial={{ scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }}
                animate={
                  animationStep === 0
                    ? { scale: 0.01, opacity: 0, rotate: p.initialRotate - 25, y: 8 }
                    : animationStep === 1
                    ? { scale: 0.48, opacity: 1, rotate: p.initialRotate, y: 0 }
                    : {
                        scale: [0.48, 0.48 * 1.03, 0.48],
                        rotate: [p.initialRotate, p.initialRotate + 2, p.initialRotate - 2, p.initialRotate],
                        opacity: 1,
                        y: 0,
                      }
                }
                transition={
                  animationStep === 2
                    ? {
                        scale: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                        rotate: { duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" },
                      }
                    : {
                        delay: p.delay,
                        duration: 2.8,
                        ease: [0.16, 1, 0.3, 1],
                      }
                }
              />
            ))}

            {/* Glowing Golden Core Pistil (revealed only upon fully blooming) */}
            <motion.circle
              cx="100"
              cy="102"
              r="4.5"
              fill="url(#gold-shimmer-grad)"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ 
                scale: animationStep === 0 ? 0 : 1, 
                opacity: animationStep === 0 ? 0 : 0.85 
              }}
              transition={{ delay: 1.2, duration: 1.5, ease: "easeOut" }}
            />

            {/* Sparkly magical pollen points orbiting the heart */}
            {animationStep >= 1 && (
              <motion.g
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 0.9, scale: 1 }}
                transition={{ duration: 1.5, delay: 1.0 }}
              >
                <circle cx="95" cy="55" r="1" fill="#FFF2D1" className="animate-pulse" />
                <circle cx="106" cy="51" r="1.5" fill="#FFF2D1" />
                <circle cx="85" cy="70" r="1" fill="#FFF2D1" />
                <circle cx="116" cy="72" r="1.2" fill="#EAD8B1" />
                <circle cx="100" cy="65" r="1.5" fill="#EAD8B1" />
              </motion.g>
            )}
          </svg>

          {/* Golden floating particles over flower */}
          {animationStep >= 1 && (
            <div className="absolute inset-0 pointer-events-none z-20">
              {Array.from({ length: 10 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute rounded-full bg-bloom-gold-light"
                  style={{
                    width: `${2 + Math.random() * 3}px`,
                    height: `${2 + Math.random() * 3}px`,
                    left: `${40 + Math.random() * 20}%`,
                    top: `${40 + Math.random() * 20}%`,
                  }}
                  animate={{
                    x: [(Math.random() - 0.5) * 60, (Math.random() - 0.5) * 140],
                    y: [(Math.random() - 0.5) * 60, -(40 + Math.random() * 70)],
                    opacity: [0, 1, 0],
                  }}
                  transition={{
                    duration: 2.2 + Math.random() * 2,
                    repeat: Infinity,
                    ease: 'easeOut',
                    delay: i * 0.2,
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Title */}
        <div className="h-16 flex items-center justify-center overflow-hidden">
          <AnimatePresence mode="wait">
            {animationStep >= 1 && (
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                className={`font-script text-4xl md:text-5xl tracking-wide ${
                  isDark ? 'text-bloom-gold-light' : 'text-bloom-rose-dark'
                }`}
              >
                Love in Full Bloom
              </motion.h1>
            )}
          </AnimatePresence>
        </div>

        {/* Enter Button or loading spinner */}
        <div className="h-16 mt-8 flex items-center justify-center">
          {animationStep === 2 ? (
            <motion.button
              id="enter-garden-btn"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={onComplete}
              className={`font-cinzel tracking-[0.2em] uppercase text-xs px-8 py-3.5 border rounded-full transition-all duration-300 shadow-sm cursor-pointer ${
                isDark
                  ? 'border-bloom-gold/50 hover:border-bloom-gold text-bloom-gold-light hover:bg-bloom-gold/10'
                  : 'border-bloom-rose/40 hover:border-bloom-rose text-bloom-rose-dark hover:bg-bloom-rose/5'
              }`}
            >
              Enter the Garden
            </motion.button>
          ) : (
            <motion.p
              initial={{ opacity: 0.3 }}
              animate={{ opacity: [0.3, 0.7, 0.3] }}
              transition={{ duration: 1.8, repeat: Infinity }}
              className={`font-serif text-sm italic ${
                isDark ? 'text-bloom-gold-light/40' : 'text-bloom-rose/60'
              }`}
            >
              The garden is cultivating...
            </motion.p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
