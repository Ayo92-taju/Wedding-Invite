import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { RsvpData } from '../types';
import { Gift, FileText, Sparkles, Check, Download, RotateCcw } from 'lucide-react';

interface RsvpSectionProps {
  isDark: boolean;
}

type RitualType = 'wax-seal' | 'flower-press' | 'ribbon-tie' | null;

export default function RsvpSection({ isDark }: RsvpSectionProps) {
  const [ritual, setRitual] = useState<RitualType>(null);
  const [formStep, setFormStep] = useState<'ritual' | 'form' | 'animating' | 'pass'>('ritual');
  const [rsvp, setRsvp] = useState<RsvpData>({
    name: '',
    email: '',
    attending: '',
    guestsCount: 1,
    dietaryNotes: '',
    message: '',
  });

  const [isDeclining, setIsDeclining] = useState(false);

  // Handle ritual choice
  const selectRitual = (type: RitualType) => {
    setRitual(type);
    setFormStep('form');
  };

  // Submit RSVP and trigger sealing animation
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rsvp.name || !rsvp.email || !rsvp.attending) {
      alert('Please provide your name, email, and RSVP response.');
      return;
    }
    
    setFormStep('animating');

    // Simulate luxury animation timing
    setTimeout(() => {
      setFormStep('pass');
    }, 3200);
  };

  // Reset RSVP form
  const handleReset = () => {
    setRsvp({
      name: '',
      email: '',
      attending: '',
      guestsCount: 1,
      dietaryNotes: '',
      message: '',
    });
    setRitual(null);
    setFormStep('ritual');
  };

  return (
    <div id="rsvp" className="relative py-24 px-4 bg-bloom-ivory dark:bg-dark-paper paper-texture overflow-hidden min-h-screen flex items-center justify-center">
      {/* Subtle gold divider line at top */}
      <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-bloom-gold/30 to-transparent"></div>

      <div className="max-w-2xl w-full flex flex-col items-center relative z-10">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <span className="font-cinzel text-bloom-gold text-xs tracking-[0.3em] uppercase block mb-3">
            Response Ritual
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-bloom-charcoal dark:text-bloom-cream italic font-light">
            RSVP Confirmation
          </h2>
          <div className="w-12 h-[1px] bg-bloom-gold/40 mx-auto mt-4"></div>
        </motion.div>

        {/* CONTAINER FOR STEPPED FLOW */}
        <div className="w-full bg-bloom-cream/50 dark:bg-dark-garden/40 rounded-3xl border border-bloom-gold/20 p-6 md:p-10 shadow-lg min-h-[420px] flex flex-col justify-center">
          
          <AnimatePresence mode="wait">
            
            {/* STEP 1: RITUAL CHOICE */}
            {formStep === 'ritual' && (
              <motion.div
                key="ritual-step"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.6 }}
                className="text-center space-y-6"
              >
                <p className="font-serif italic text-bloom-sage-dark dark:text-bloom-sage text-base max-w-lg mx-auto leading-relaxed">
                  Before confirming your presence, choose a gentle sealing ritual to bind your invitation card and craft your custom entry seal.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                  
                  {/* Option 1: Wax Seal */}
                  <motion.div
                    whileHover={{ scale: 1.03, y: -4 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => selectRitual('wax-seal')}
                    className="p-6 bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 hover:border-bloom-gold rounded-2xl cursor-pointer text-center group flex flex-col items-center justify-center space-y-3"
                  >
                    <div className="w-12 h-12 rounded-full bg-bloom-rose/10 flex items-center justify-center text-bloom-rose group-hover:bg-bloom-rose group-hover:text-bloom-ivory transition-colors">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <h3 className="font-cinzel text-xs tracking-wider uppercase text-bloom-charcoal dark:text-bloom-cream">
                      Wax Seal
                    </h3>
                    <p className="font-serif text-[11px] italic text-bloom-sage-dark dark:text-bloom-sage leading-relaxed">
                      Press your RSVP with hot rose wax and gold foil
                    </p>
                  </motion.div>

                  {/* Option 2: Flower Press */}
                  <motion.div
                    whileHover={{ scale: 1.03, y: -4 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => selectRitual('flower-press')}
                    className="p-6 bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 hover:border-bloom-gold rounded-2xl cursor-pointer text-center group flex flex-col items-center justify-center space-y-3"
                  >
                    <div className="w-12 h-12 rounded-full bg-bloom-sage/10 flex items-center justify-center text-bloom-sage group-hover:bg-bloom-sage group-hover:text-bloom-ivory transition-colors">
                      <Check className="w-5 h-5" />
                    </div>
                    <h3 className="font-cinzel text-xs tracking-wider uppercase text-bloom-charcoal dark:text-bloom-cream">
                      Press a Flower
                    </h3>
                    <p className="font-serif text-[11px] italic text-bloom-sage-dark dark:text-bloom-sage leading-relaxed">
                      Press a fresh field blossom into handmade paper fibers
                    </p>
                  </motion.div>

                  {/* Option 3: Ribbon Tie */}
                  <motion.div
                    whileHover={{ scale: 1.03, y: -4 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => selectRitual('ribbon-tie')}
                    className="p-6 bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 hover:border-bloom-gold rounded-2xl cursor-pointer text-center group flex flex-col items-center justify-center space-y-3"
                  >
                    <div className="w-12 h-12 rounded-full bg-bloom-gold/10 flex items-center justify-center text-bloom-gold group-hover:bg-bloom-gold group-hover:text-bloom-ivory transition-colors">
                      <Gift className="w-5 h-5" />
                    </div>
                    <h3 className="font-cinzel text-xs tracking-wider uppercase text-bloom-charcoal dark:text-bloom-cream">
                      Ribbon Tie
                    </h3>
                    <p className="font-serif text-[11px] italic text-bloom-sage-dark dark:text-bloom-sage leading-relaxed">
                      Tie a luxurious silk ribbon around the letter deck
                    </p>
                  </motion.div>

                </div>
              </motion.div>
            )}

            {/* STEP 2: INVITATION FORM */}
            {formStep === 'form' && (
              <motion.form
                key="form-step"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.5 }}
                onSubmit={handleSubmit}
                className="space-y-6"
              >
                {/* Back button */}
                <button
                  type="button"
                  onClick={() => setFormStep('ritual')}
                  className="font-serif text-xs italic text-bloom-sage-dark hover:text-bloom-rose flex items-center gap-1 cursor-pointer"
                >
                  &larr; Change sealing ritual ({ritual === 'wax-seal' ? 'Wax Seal' : ritual === 'flower-press' ? 'Flower Press' : 'Ribbon Tie'})
                </button>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Name */}
                  <div className="space-y-1">
                    <label className="font-cinzel text-[10px] tracking-widest text-bloom-gold uppercase block">
                      Guest Full Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Juliet Capulet"
                      value={rsvp.name}
                      onChange={(e) => setRsvp({ ...rsvp, name: e.target.value })}
                      className="w-full bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-bloom-gold focus:ring-1 focus:ring-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-1">
                    <label className="font-cinzel text-[10px] tracking-widest text-bloom-gold uppercase block">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. juliet@email.com"
                      value={rsvp.email}
                      onChange={(e) => setRsvp({ ...rsvp, email: e.target.value })}
                      className="w-full bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-bloom-gold focus:ring-1 focus:ring-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                    />
                  </div>
                </div>

                {/* Attendance */}
                <div className="space-y-2">
                  <label className="font-cinzel text-[10px] tracking-widest text-bloom-gold uppercase block text-center">
                    RSVP Response
                  </label>
                  <div className="flex gap-4 justify-center">
                    <button
                      type="button"
                      id="rsvp-attend-btn"
                      onClick={() => {
                        setRsvp({ ...rsvp, attending: 'yes' });
                        setIsDeclining(false);
                      }}
                      className={`flex-1 max-w-[200px] py-3.5 border rounded-2xl font-serif text-sm italic transition-all duration-300 cursor-pointer ${
                        rsvp.attending === 'yes'
                          ? 'border-bloom-rose bg-bloom-rose text-bloom-ivory font-medium shadow-md'
                          : 'border-bloom-gold/20 hover:border-bloom-gold/60 text-bloom-charcoal dark:text-bloom-cream hover:bg-bloom-rose/5'
                      }`}
                    >
                      Joyfully Attend
                    </button>
                    <button
                      type="button"
                      id="rsvp-decline-btn"
                      onClick={() => {
                        setRsvp({ ...rsvp, attending: 'no' });
                        setIsDeclining(true);
                      }}
                      className={`flex-1 max-w-[200px] py-3.5 border rounded-2xl font-serif text-sm italic transition-all duration-300 cursor-pointer ${
                        rsvp.attending === 'no'
                          ? 'border-bloom-sage bg-bloom-sage text-bloom-ivory font-medium shadow-md'
                          : 'border-bloom-gold/20 hover:border-bloom-gold/60 text-bloom-charcoal dark:text-bloom-cream hover:bg-bloom-sage/5'
                      }`}
                    >
                      Regretfully Decline
                    </button>
                  </div>
                </div>

                {!isDeclining && rsvp.attending === 'yes' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-5"
                  >
                    {/* Guest count */}
                    <div className="space-y-1">
                      <label className="font-cinzel text-[10px] tracking-widest text-bloom-gold uppercase block">
                        Number of Seats
                      </label>
                      <select
                        value={rsvp.guestsCount}
                        onChange={(e) => setRsvp({ ...rsvp, guestsCount: Number(e.target.value) })}
                        className="w-full bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                      >
                        <option value={1}>1 Guest</option>
                        <option value={2}>2 Guests</option>
                        <option value={3}>3 Guests (Includes Family)</option>
                      </select>
                    </div>

                    {/* Dietary Notes */}
                    <div className="space-y-1">
                      <label className="font-cinzel text-[10px] tracking-widest text-bloom-gold uppercase block">
                        Dietary Requirements
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Vegan, Gluten-Free, None"
                        value={rsvp.dietaryNotes}
                        onChange={(e) => setRsvp({ ...rsvp, dietaryNotes: e.target.value })}
                        className="w-full bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                      />
                    </div>
                  </motion.div>
                )}

                {/* Love Note for Couple */}
                <div className="space-y-1">
                  <label className="font-cinzel text-[10px] tracking-widest text-bloom-gold uppercase block">
                    {isDeclining ? "Blessing / Message for the Couple" : "Love Note or Song Request"}
                  </label>
                  <textarea
                    rows={3}
                    placeholder={isDeclining ? "Send your love or warm wishes..." : "A song to get you on the dancefloor, or a warm note of joy..."}
                    value={rsvp.message}
                    onChange={(e) => setRsvp({ ...rsvp, message: e.target.value })}
                    className="w-full bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                  />
                </div>

                {/* Submit Action */}
                <div className="flex justify-center pt-2">
                  <motion.button
                    type="submit"
                    id="submit-rsvp-btn"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full max-w-sm py-4 bg-bloom-gold hover:bg-bloom-gold/90 text-bloom-ivory font-cinzel text-xs tracking-[0.2em] uppercase rounded-full shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer"
                  >
                    Confirm &amp; Sealing Ritual
                  </motion.button>
                </div>
              </motion.form>
            )}

            {/* STEP 3: ANIMATING RITUAL PREPARATION */}
            {formStep === 'animating' && (
              <motion.div
                key="animating-step"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center text-center space-y-6 py-10"
              >
                {ritual === 'wax-seal' && (
                  <>
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      {/* Wax pool forming */}
                      <motion.div
                        initial={{ scale: 0.1, opacity: 0 }}
                        animate={{ scale: [0.1, 1.2, 1], opacity: 0.9 }}
                        transition={{ duration: 1.5, ease: 'easeOut' }}
                        className="absolute w-20 h-20 rounded-full bg-bloom-rose filter blur-xs"
                      />
                      
                      {/* Stamp pressing down */}
                      <motion.div
                        initial={{ y: -80, opacity: 0 }}
                        animate={{ y: [ -80, 0, -5, 0 ], opacity: [ 0, 1, 1, 1 ] }}
                        transition={{ delay: 1, duration: 1.2, ease: 'easeOut' }}
                        className="relative z-10 w-16 h-16 bg-bloom-gold text-bloom-ivory rounded-full flex items-center justify-center shadow-xl border border-bloom-gold-light"
                      >
                        <svg viewBox="0 0 100 100" fill="currentColor" className="w-10 h-10">
                          <path d="M50 20 L60 40 L85 40 L65 55 L75 80 L50 65 L25 80 L35 55 L15 40 L40 40 Z" />
                        </svg>
                      </motion.div>

                      {/* Sparkle effects on impact */}
                      <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: [0, 1.5, 0], opacity: [0, 1, 0] }}
                        transition={{ delay: 1.6, duration: 0.8 }}
                        className="absolute inset-0 border border-bloom-gold rounded-full"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-cinzel text-xs tracking-[0.25em] uppercase text-bloom-gold">
                        Pouring Gold Foil Wax
                      </h3>
                      <p className="font-serif italic text-sm text-bloom-sage-dark dark:text-bloom-sage">
                        Pressing the seal onto the handmade letter...
                      </p>
                    </div>
                  </>
                )}

                {ritual === 'flower-press' && (
                  <>
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      {/* Bottom Plate */}
                      <div className="absolute w-24 h-24 bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-lg shadow-inner"></div>
                      
                      {/* Flower falling */}
                      <motion.div
                        initial={{ y: -50, rotate: 0, opacity: 0 }}
                        animate={{ y: 0, rotate: 145, opacity: 1 }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className="absolute text-bloom-rose"
                      >
                        <svg viewBox="0 0 100 100" fill="currentColor" className="w-12 h-12">
                          <path d="M50 10 C60 30, 80 30, 50 60 C20 30, 40 30, 50 10 Z" />
                        </svg>
                      </motion.div>

                      {/* Glass Platen pressing down */}
                      <motion.div
                        initial={{ scaleY: 2, opacity: 0 }}
                        animate={{ scaleY: 1, opacity: 0.8 }}
                        transition={{ delay: 1.1, duration: 0.8, ease: 'easeIn' }}
                        className="absolute w-26 h-26 bg-white/20 border border-white/50 rounded-lg shadow-md backdrop-blur-xs flex items-center justify-center"
                      >
                        <div className="border border-bloom-gold/30 rounded w-full h-full"></div>
                      </motion.div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-cinzel text-xs tracking-[0.25em] uppercase text-bloom-gold">
                        Pressing Field Blossom
                      </h3>
                      <p className="font-serif italic text-sm text-bloom-sage-dark dark:text-bloom-sage">
                        Squeezing the petals to infuse fibers with color...
                      </p>
                    </div>
                  </>
                )}

                {ritual === 'ribbon-tie' && (
                  <>
                    <div className="relative w-32 h-32 flex items-center justify-center overflow-hidden">
                      {/* Bow path drawing */}
                      <motion.svg
                        viewBox="0 0 100 100"
                        className="w-24 h-24 text-bloom-rose"
                      >
                        <motion.path
                          d="M10 50 Q30 20 50 50 Q70 20 90 50 Q75 80 50 50 Q25 80 10 50 Z"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          initial={{ pathLength: 0 }}
                          animate={{ pathLength: 1 }}
                          transition={{ duration: 2, ease: 'easeInOut' }}
                        />
                        <motion.circle
                          cx="50"
                          cy="50"
                          r="6"
                          fill="#C5A059"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 1.5 }}
                        />
                      </motion.svg>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-cinzel text-xs tracking-[0.25em] uppercase text-bloom-gold">
                        Tying Silk Knot
                      </h3>
                      <p className="font-serif italic text-sm text-bloom-sage-dark dark:text-bloom-sage">
                        Drawing the blush satin ribbon close and tight...
                      </p>
                    </div>
                  </>
                )}
              </motion.div>
            )}

            {/* STEP 4: GENERATED SE SEAL PASS */}
            {formStep === 'pass' && (
              <motion.div
                key="pass-step"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ type: 'spring', damping: 15 }}
                className="text-center flex flex-col items-center space-y-6"
              >
                {/* Visual success banner */}
                <div className="w-12 h-12 rounded-full bg-bloom-sage/10 text-bloom-sage flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>

                <div className="space-y-1">
                  <h3 className="font-cinzel text-sm tracking-[0.2em] uppercase text-bloom-sage-dark dark:text-bloom-sage">
                    {rsvp.attending === 'yes' ? 'Ritual Complete!' : 'Blessing Received!'}
                  </h3>
                  <p className="font-serif italic text-xs text-bloom-sage">
                    {rsvp.attending === 'yes'
                      ? 'Your personalized entry pass has blossomed.'
                      : 'We are saddened you cannot attend but thank you for your love.'}
                  </p>
                </div>

                {rsvp.attending === 'yes' ? (
                  /* PERSONALIZED SEAL TICKET */
                  <div className="relative w-full max-w-sm bg-bloom-ivory dark:bg-dark-paper border-2 border-bloom-gold/40 rounded-3xl p-6 shadow-xl paper-texture select-none foil-gold overflow-hidden">
                    {/* Background faint mandala or florals */}
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(197,160,89,0.05)_0%,transparent_70%)] pointer-events-none"></div>

                    {/* Ribbon header or ticket tear marks */}
                    <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-bloom-rose via-bloom-gold to-bloom-sage"></div>

                    {/* Ticket Header */}
                    <div className="border-b border-dashed border-bloom-gold/30 pb-4 flex flex-col items-center">
                      <span className="font-cinzel text-[8px] tracking-[0.3em] uppercase text-bloom-gold block">
                        Official Entry Pass
                      </span>
                      <h4 className="font-script text-3xl text-bloom-rose-dark dark:text-bloom-blush mt-1">
                        Victor &amp; Nimi
                      </h4>
                      <p className="font-serif text-[10px] tracking-widest text-bloom-sage-dark dark:text-bloom-sage uppercase mt-0.5">
                        Aug 12, 2026 &bull; Glasshouse
                      </p>
                    </div>

                    {/* Ticket Center: Personalized Wax Seal with Embedded QR */}
                    <div className="py-6 flex flex-col items-center justify-center space-y-4">
                      {/* The Wax Seal Outer Ring */}
                      <div className="relative w-36 h-36 rounded-full bg-bloom-rose/95 dark:bg-bloom-rose-dark flex items-center justify-center shadow-lg border-2 border-bloom-gold">
                        <div className="absolute inset-1.5 border border-dashed border-bloom-gold-light/30 rounded-full"></div>
                        
                        {/* Realistic melt circles */}
                        <div className="absolute top-0 left-4 w-6 h-6 rounded-full bg-bloom-rose opacity-80 -mt-1"></div>
                        <div className="absolute bottom-1 right-2 w-8 h-8 rounded-full bg-bloom-rose opacity-80 -mr-1"></div>
                        
                        {/* Embedding the QR code into center of seal */}
                        <div className="relative w-24 h-24 bg-white rounded-2xl flex items-center justify-center p-2 border border-bloom-gold shadow-inner overflow-hidden">
                          {/* MOCK HIGH QUALITY QR CODE SVG with flower outline in center */}
                          <svg viewBox="0 0 100 100" className="w-full h-full text-bloom-charcoal">
                            {/* QR Blocks */}
                            <path d="M0,0 h30 v30 h-30 z M10,10 h10 v10 h-10 z M70,0 h30 v30 h-30 z M80,10 h10 v10 h-10 z M0,70 h30 v30 h-30 z M10,80 h10 v10 h-10 z" fill="currentColor" />
                            <path d="M40,0 h10 v10 h-10 z M50,20 h10 v10 h-10 z M40,40 h20 v10 h-20 z M30,50 h10 v10 h-10 z M0,40 h10 v10 h-10 z M10,50 h10 v10 h-10 z M20,40 h10 v10 h-10 z" fill="currentColor" />
                            <path d="M70,40 h10 v10 h-10 z M80,50 h20 v10 h-20 z M90,40 h10 v10 h-10 z M60,60 h10 v10 h-10 z" fill="currentColor" />
                            <path d="M40,70 h20 v10 h-20 z M50,90 h10 v10 h-10 z M40,80 h10 v10 h-10 z M30,80 h10 v10 h-10 z M70,80 h10 v10 h-10 z M80,90 h10 v10 h-10 z M90,80 h10 v10 h-10 z" fill="currentColor" />
                            
                            {/* Floral icon inside QR center */}
                            <g transform="translate(38,38) scale(0.24)" className="text-bloom-rose">
                              <rect x="0" y="0" width="100" height="100" fill="white" rx="10" />
                              <circle cx="50" cy="50" r="28" fill="#C68B84" />
                              <circle cx="50" cy="50" r="12" fill="#EAD8B1" />
                            </g>
                          </svg>
                        </div>
                      </div>

                      {/* Guest Metadata inside pass */}
                      <div className="space-y-0.5 text-center">
                        <span className="font-serif text-[10px] uppercase tracking-widest text-bloom-sage-dark dark:text-bloom-sage">
                          Guest of Honor
                        </span>
                        <h5 className="font-serif text-lg text-bloom-charcoal dark:text-bloom-cream font-medium">
                          {rsvp.name}
                        </h5>
                        <p className="font-serif text-[11px] italic text-bloom-rose">
                          {rsvp.guestsCount === 1 ? 'Single Admission' : `Table Seat Block (${rsvp.guestsCount} Seats)`}
                        </p>
                      </div>
                    </div>

                    {/* Security stamp Footer */}
                    <div className="border-t border-dashed border-bloom-gold/30 pt-4 flex justify-between items-center text-[9px] font-mono text-bloom-gold">
                      <span>SECURE SEAL #N{Math.floor(1000 + Math.random() * 9000)}V</span>
                      <span>VERIFIED PASS</span>
                    </div>
                  </div>
                ) : (
                  /* DECLINE WRITING NOTE */
                  <div className="relative w-full max-w-md bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 rounded-2xl p-8 shadow-md text-left">
                    <p className="font-serif italic text-sm text-bloom-charcoal/80 dark:text-bloom-cream/80 leading-relaxed mb-4">
                      &ldquo;{rsvp.message || "Sending you all our love and light as you begin this beautiful garden story together!"}&rdquo;
                    </p>
                    <p className="font-serif text-right text-xs text-bloom-rose-dark dark:text-bloom-rose font-medium">
                      &mdash; {rsvp.name}
                    </p>
                  </div>
                )}

                {/* Post RSVP Options */}
                <div className="flex gap-4 pt-2">
                  {rsvp.attending === 'yes' && (
                    <button
                      id="download-pass-btn"
                      onClick={() => alert('Wax Seal Pass saved to your device files!')}
                      className="px-6 py-2.5 bg-bloom-sage hover:bg-bloom-sage-dark text-bloom-ivory font-cinzel text-[10px] tracking-widest uppercase rounded-full flex items-center gap-2 cursor-pointer shadow-sm hover:shadow-md transition-all duration-300"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Save Seal Pass
                    </button>
                  )}
                  <button
                    id="reset-rsvp-btn"
                    onClick={handleReset}
                    className="px-6 py-2.5 border border-bloom-gold/30 hover:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream hover:bg-bloom-gold/5 font-cinzel text-[10px] tracking-widest uppercase rounded-full flex items-center gap-2 cursor-pointer transition-all duration-300"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset Form
                  </button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </div>
      </div>
    </div>
  );
}
