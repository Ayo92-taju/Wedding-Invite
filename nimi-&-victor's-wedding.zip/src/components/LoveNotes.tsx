import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LoveNote } from '../types';
import { Send, MessageSquare, Feather, Bookmark } from 'lucide-react';

interface LoveNotesProps {
  isDark: boolean;
}

const initialNotes: LoveNote[] = [
  {
    id: 'n1',
    sender: 'Aunt Susan & Uncle Robert',
    relationship: 'Family',
    message: 'Can we bring children to the ceremony? We want to make sure the greenhouse has enough seats!',
    date: 'June 28, 2026',
    response: 'Our glasshouse is a delicate, cozy sanctuary, so we have chosen to keep the ceremony and dinner an adults-only celebration. We thank you so much for understanding! — Nimi & Victor',
  },
  {
    id: 'n2',
    sender: 'Chloe & Jack',
    relationship: 'Bridal Party',
    message: 'What is the exact dress code details for "Ethereal Garden"? Help us pick our fabrics!',
    date: 'June 29, 2026',
    response: 'Think light, romantic, and dreamy! Flowy pastel gowns, soft floral prints, beige/linen suits, or soft sage blazers. Please avoid heavy dark blacks or super bright neons! — Nimi',
  },
  {
    id: 'n3',
    sender: 'Michael Briggs',
    relationship: 'Groomsman',
    message: 'What time does the coach departure from Rosewood Manor? Don\'t want to be late!',
    date: 'June 30, 2026',
    response: 'The coaches leave Rosewood Manor main drive at exactly 1:15 PM. We recommend gathering in the lobby by 1:00 PM for a quick pre-departure prosecco! — Victor',
  }
];

export default function LoveNotes({ isDark }: LoveNotesProps) {
  const [notes, setNotes] = useState<LoveNote[]>(initialNotes);
  const [name, setName] = useState('');
  const [relation, setRelation] = useState('Friend');
  const [msg, setMsg] = useState('');

  const submitNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !msg) return;

    const newNote: LoveNote = {
      id: `n-${Date.now()}`,
      sender: name,
      relationship: relation,
      message: msg,
      date: 'Today',
    };

    setNotes([newNote, ...notes]);
    setName('');
    setMsg('');
  };

  // Organic background colors and angles for the notes wall
  const getNoteStyle = (idx: number) => {
    const rotations = ['rotate-1', '-rotate-1', 'rotate-2', '-rotate-2', 'rotate-0'];
    const backgrounds = [
      'bg-bloom-ivory border-bloom-rose/20',
      'bg-bloom-cream border-bloom-sage/20',
      'bg-bloom-ivory/95 border-bloom-gold/20',
    ];

    const rot = rotations[idx % rotations.length];
    const bg = backgrounds[idx % backgrounds.length];

    return `${rot} ${bg}`;
  };

  return (
    <div id="notes" className="relative py-24 px-4 bg-bloom-cream/20 dark:bg-dark-garden/10 overflow-hidden min-h-screen">
      <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-bloom-gold/20 to-transparent"></div>

      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="font-cinzel text-bloom-gold text-xs tracking-[0.3em] uppercase block mb-3">
            Wedding Updates &amp; Q&amp;A
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-bloom-charcoal dark:text-bloom-cream italic font-light">
            Love Notes
          </h2>
          <div className="w-12 h-[1px] bg-bloom-gold/40 mx-auto mt-4"></div>
          <p className="font-serif italic text-sm text-bloom-sage-dark dark:text-bloom-sage max-w-lg mx-auto mt-6 leading-relaxed">
            Have a question about lodging or details? Or want to send us a warm blessing? Write a love note below, and we will pen a handwritten reply on our notes wall.
          </p>
        </motion.div>

        {/* SECTION LAYOUT: TWO COLS (FORM AND WALL) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* LEFT: FORM BOX */}
          <div className="lg:col-span-4 bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 p-6 md:p-8 rounded-3xl shadow-sm paper-texture">
            <div className="flex items-center gap-2 mb-6">
              <Feather className="w-4 h-4 text-bloom-rose" />
              <h3 className="font-cinzel text-xs tracking-wider uppercase text-bloom-charcoal dark:text-bloom-cream">
                Pen a Note
              </h3>
            </div>

            <form onSubmit={submitNote} className="space-y-4">
              {/* Name */}
              <div className="space-y-1">
                <label className="font-cinzel text-[9px] tracking-widest text-bloom-gold uppercase block">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Grandma Rose"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-bloom-cream/40 dark:bg-dark-garden/20 border border-bloom-gold/20 rounded-xl px-4 py-2.5 text-xs focus:outline-hidden focus:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                />
              </div>

              {/* Relationship */}
              <div className="space-y-1">
                <label className="font-cinzel text-[9px] tracking-widest text-bloom-gold uppercase block">
                  Relationship
                </label>
                <select
                  value={relation}
                  onChange={(e) => setRelation(e.target.value)}
                  className="w-full bg-bloom-cream/40 dark:bg-dark-garden/20 border border-bloom-gold/20 rounded-xl px-4 py-2.5 text-xs focus:outline-hidden focus:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                >
                  <option value="Friend">Friend</option>
                  <option value="Family">Family</option>
                  <option value="Bridal Party">Bridal Party</option>
                </select>
              </div>

              {/* Message */}
              <div className="space-y-1">
                <label className="font-cinzel text-[9px] tracking-widest text-bloom-gold uppercase block">
                  Blessing or Question
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Ask a question or share a warm wish..."
                  value={msg}
                  onChange={(e) => setMsg(e.target.value)}
                  className="w-full bg-bloom-cream/40 dark:bg-dark-garden/20 border border-bloom-gold/20 rounded-xl px-4 py-2.5 text-xs focus:outline-hidden focus:border-bloom-gold text-bloom-charcoal dark:text-bloom-cream"
                />
              </div>

              <button
                type="submit"
                id="submit-love-note-btn"
                className="w-full py-3 bg-bloom-gold hover:bg-bloom-gold/90 text-bloom-ivory font-cinzel text-[10px] tracking-widest uppercase rounded-full shadow-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                Pin Love Note
              </button>
            </form>
          </div>

          {/* RIGHT: THE SCATTERED NOTES WALL */}
          <div className="lg:col-span-8 space-y-6">
            <div className="flex items-center gap-2 mb-2 text-bloom-sage-dark dark:text-bloom-sage">
              <MessageSquare className="w-4 h-4" />
              <span className="font-cinzel text-xs tracking-wider uppercase">
                Notes Wall ({notes.length} pinned)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative">
              <AnimatePresence initial={false}>
                {notes.map((note, idx) => (
                  <motion.div
                    key={note.id}
                    initial={{ opacity: 0, scale: 0.9, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: -15 }}
                    transition={{ type: 'spring', damping: 15 }}
                    className={`p-6 border rounded-2xl shadow-xs paper-texture flex flex-col justify-between min-h-[180px] transition-transform duration-300 hover:scale-[1.01] hover:shadow-md relative group ${getNoteStyle(
                      idx
                    )}`}
                  >
                    {/* Tiny visual ribbon binder */}
                    <Bookmark className="absolute top-0 right-4 w-4 h-6 text-bloom-rose opacity-20 group-hover:opacity-100 transition-opacity" />

                    <div>
                      {/* Meta */}
                      <div className="flex justify-between items-center mb-3">
                        <span className="font-cinzel text-[8px] tracking-widest text-bloom-gold uppercase">
                          {note.relationship}
                        </span>
                        <span className="font-serif text-[10px] italic text-bloom-sage-dark">
                          {note.date}
                        </span>
                      </div>

                      {/* Guest Question / Message */}
                      <p className="font-serif italic text-xs md:text-sm text-bloom-charcoal/90 dark:text-bloom-cream/90 leading-relaxed mb-4">
                        &ldquo;{note.message}&rdquo;
                      </p>
                    </div>

                    {/* Bottom Guest attribution */}
                    <div className="flex justify-between items-end border-t border-dashed border-bloom-gold/15 pt-3">
                      <span className="font-serif text-xs font-semibold text-bloom-charcoal dark:text-bloom-cream">
                        &mdash; {note.sender}
                      </span>
                    </div>

                    {/* Coupled Handwritten Response */}
                    {note.response && (
                      <div className="mt-4 pt-3 border-t border-bloom-sage/20 pl-3 border-l-2 border-bloom-rose/40 bg-bloom-rose/5 rounded-r-lg">
                        <span className="font-cinzel text-[8px] text-bloom-rose tracking-wider uppercase block mb-1">
                          Reply from Victor &amp; Nimi:
                        </span>
                        <p className="font-serif italic text-xs text-bloom-rose-dark dark:text-bloom-blush leading-relaxed">
                          {note.response}
                        </p>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
