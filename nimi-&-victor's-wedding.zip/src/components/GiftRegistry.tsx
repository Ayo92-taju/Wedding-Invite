import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sprout, TreePine, Plane, Sofa, Hammer, GlassWater, Heart } from 'lucide-react';
import { RegistryItem } from '../types';

interface GiftRegistryProps {
  isDark: boolean;
}

const initialRegistryItems: RegistryItem[] = [
  {
    id: 'g1',
    title: 'Heritage Olive & Fig Trees',
    category: 'Planting Roots',
    price: '£250 total',
    description: 'Help us plant mature heritage fig and olive trees in our backyard garden. They will grow alongside our love, producing shade and fruit for years to come.',
    iconName: 'TreePine',
    raised: 75,
  },
  {
    id: 'g2',
    title: 'Amalfi Botanical Honeymoon',
    category: 'Garden Wandering',
    price: '£1,500 total',
    description: 'We are planning a journey to wander the hanging cliff gardens of Ravello and the citrus orchards of Amalfi. Contribute to our flights, floral villas, and walking tours.',
    iconName: 'Plane',
    raised: 48,
  },
  {
    id: 'g3',
    title: 'Seedling Greenhouse Fund',
    category: 'Sowing Seeds',
    price: '£800 total',
    description: 'Help us assemble a small backyard cedar greenhouse where Nimi can cultivate heirloom tomatoes, organic herbs, and baby hydrangeas from seeds.',
    iconName: 'Sprout',
    raised: 62,
  },
  {
    id: 'g4',
    title: 'Backyard Cedar Lounge chairs',
    category: 'Garden Living',
    price: '£350 total',
    description: 'Handcrafted outdoor cedar Adirondack chairs where we can drink chamomile tea together on quiet Sunday mornings, listening to the birds chirping.',
    iconName: 'Sofa',
    raised: 25,
  },
  {
    id: 'g5',
    title: 'English Garden Tool Set',
    category: 'Cultivation Tools',
    price: '£120 total',
    description: 'Professional-grade forged steel pruning shears, weeders, oak-handle spades, and durable canvas carry bags to help us maintain our flowerbeds.',
    iconName: 'Hammer',
    raised: 90,
  }
];

export default function GiftRegistry({ isDark }: GiftRegistryProps) {
  const [items, setItems] = useState<RegistryItem[]>(initialRegistryItems);
  const [selectedItem, setSelectedItem] = useState<RegistryItem | null>(null);
  const [contribAmount, setContribAmount] = useState('50');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleWaterItem = (item: RegistryItem) => {
    setSelectedItem(item);
    setContribAmount('50');
    setIsSuccess(false);
  };

  const submitContribution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;

    // Update local percentage slightly to give interactive satisfaction
    const addedPercent = Math.min(25, Math.max(5, Math.floor(Number(contribAmount) / 5)));
    setItems((prev) =>
      prev.map((itm) => {
        if (itm.id === selectedItem.id) {
          return { ...itm, raised: Math.min(100, itm.raised + addedPercent) };
        }
        return itm;
      })
    );

    setIsSuccess(true);
    setTimeout(() => {
      setSelectedItem(null);
      setIsSuccess(false);
    }, 2500);
  };

  // Icon mapping
  const getIcon = (name: string) => {
    switch (name) {
      case 'TreePine': return <TreePine className="w-5 h-5 text-bloom-sage" />;
      case 'Plane': return <Plane className="w-5 h-5 text-bloom-sage" />;
      case 'Sprout': return <Sprout className="w-5 h-5 text-bloom-sage" />;
      case 'Sofa': return <Sofa className="w-5 h-5 text-bloom-sage" />;
      case 'Hammer': return <Hammer className="w-5 h-5 text-bloom-sage" />;
      default: return <Heart className="w-5 h-5 text-bloom-sage" />;
    }
  };

  return (
    <div id="registry" className="relative py-24 px-4 overflow-hidden min-h-screen">
      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="font-cinzel text-bloom-gold text-xs tracking-[0.3em] uppercase block mb-3">
            Gift Registry
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-bloom-charcoal dark:text-bloom-cream italic font-light">
            Garden of Gifts
          </h2>
          <div className="w-12 h-[1px] bg-bloom-gold/40 mx-auto mt-4"></div>
          <p className="font-serif italic text-sm text-bloom-sage-dark dark:text-bloom-sage max-w-lg mx-auto mt-6 leading-relaxed">
            Your presence at our wedding is the greatest blooming gift of all. However, should you wish to honour us with a token of love, we invite you to help &ldquo;water&rdquo; our future garden dreams.
          </p>
        </motion.div>

        {/* REGISTRY GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {items.map((item) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className="bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 p-6 rounded-3xl shadow-sm flex flex-col justify-between paper-texture h-full relative group overflow-hidden"
            >
              {/* Subtle water-wave background when hovering */}
              <div className="absolute inset-0 bg-gradient-to-t from-bloom-sage/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>

              <div>
                {/* Category & Icon */}
                <div className="flex justify-between items-center mb-4">
                  <span className="font-cinzel text-[9px] tracking-widest text-bloom-gold uppercase">
                    {item.category}
                  </span>
                  <div className="w-10 h-10 rounded-full bg-bloom-sage/10 flex items-center justify-center">
                    {getIcon(item.iconName)}
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-serif text-xl text-bloom-charcoal dark:text-bloom-cream font-medium mb-1">
                  {item.title}
                </h3>
                <span className="font-serif italic text-xs text-bloom-rose-dark dark:text-bloom-rose block mb-4">
                  {item.price}
                </span>

                <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/80 leading-relaxed mb-6">
                  {item.description}
                </p>
              </div>

              {/* Progress Tracker (Watering level) */}
              <div className="space-y-3 pt-4 border-t border-dashed border-bloom-gold/10">
                <div className="flex justify-between items-center text-[10px] font-cinzel">
                  <span className="text-bloom-sage-dark dark:text-bloom-sage">Watering Progress</span>
                  <span className="text-bloom-gold font-medium">{item.raised}% Funded</span>
                </div>
                {/* Custom Progress Bar */}
                <div className="w-full h-2 rounded-full bg-bloom-sage/15 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${item.raised}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.5, ease: 'easeOut' }}
                    className="h-full rounded-full bg-gradient-to-r from-bloom-sage via-bloom-rose to-bloom-gold"
                  ></motion.div>
                </div>

                {/* Contribution Action Trigger */}
                <button
                  id={`water-gift-btn-${item.id}`}
                  onClick={() => handleWaterItem(item)}
                  className="w-full py-2.5 mt-2 bg-bloom-ivory hover:bg-bloom-rose text-bloom-rose-dark hover:text-bloom-ivory border border-bloom-rose/30 hover:border-bloom-rose font-cinzel text-[10px] tracking-widest uppercase rounded-full transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <GlassWater className="w-3.5 h-3.5" />
                  Water this Dream
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* POPUP OVERLAY MODAL FOR CONTRIBUTION */}
        <AnimatePresence>
          {selectedItem && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/30 rounded-3xl p-6 md:p-8 w-full max-w-md shadow-2xl relative paper-texture"
              >
                {/* Close Button */}
                <button
                  id="close-gift-modal-btn"
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-4 right-4 text-bloom-rose hover:text-bloom-rose-dark font-serif text-sm italic"
                >
                  Close
                </button>

                {!isSuccess ? (
                  <form onSubmit={submitContribution} className="space-y-6">
                    <div className="text-center space-y-1">
                      <span className="font-cinzel text-[9px] text-bloom-gold tracking-widest uppercase">
                        Watering Invitation
                      </span>
                      <h3 className="font-serif text-2xl text-bloom-charcoal dark:text-bloom-cream font-medium">
                        {selectedItem.title}
                      </h3>
                      <p className="font-serif italic text-xs text-bloom-sage">
                        Seed a contribution to this garden dream
                      </p>
                    </div>

                    {/* Sliding contribution amount */}
                    <div className="space-y-3 pt-2">
                      <div className="flex justify-between items-center text-xs font-cinzel">
                        <span className="text-bloom-sage-dark dark:text-bloom-sage">Contribution Value</span>
                        <span className="text-bloom-gold text-sm font-semibold">£{contribAmount}</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="250"
                        step="10"
                        value={contribAmount}
                        onChange={(e) => setContribAmount(e.target.value)}
                        className="w-full accent-bloom-gold cursor-pointer"
                      />
                      <div className="flex justify-between text-[10px] font-mono text-bloom-sage">
                        <span>£10</span>
                        <span>£120</span>
                        <span>£250</span>
                      </div>
                    </div>

                    <div className="bg-bloom-cream/50 dark:bg-dark-garden/20 p-4 rounded-xl border border-bloom-gold/10 space-y-1">
                      <p className="font-serif text-[11px] italic text-bloom-sage-dark dark:text-bloom-sage leading-relaxed">
                        A simulated secure portal link will be generated. In the live integration, this connects to Stripe / bank transfer widgets.
                      </p>
                    </div>

                    <button
                      type="submit"
                      id="submit-gift-water-btn"
                      className="w-full py-3.5 bg-bloom-rose hover:bg-bloom-rose-dark text-bloom-ivory font-cinzel text-xs tracking-[0.2em] uppercase rounded-full shadow-md transition-colors cursor-pointer"
                    >
                      Pour £{contribAmount} Love
                    </button>
                  </form>
                ) : (
                  <motion.div
                    initial={{ scale: 0.9 }}
                    animate={{ scale: 1 }}
                    className="text-center py-10 space-y-4"
                  >
                    <div className="w-16 h-16 rounded-full bg-bloom-sage/10 text-bloom-sage flex items-center justify-center mx-auto">
                      <Heart className="w-8 h-8 fill-currentColor" />
                    </div>
                    <h3 className="font-serif text-2xl text-bloom-charcoal dark:text-bloom-cream font-light">
                      Watered with Love!
                    </h3>
                    <p className="font-serif italic text-sm text-bloom-sage-dark dark:text-bloom-sage max-w-xs mx-auto">
                      Thank you for helping our romantic garden grow. Your blessing makes our future blossom beautifully.
                    </p>
                  </motion.div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
