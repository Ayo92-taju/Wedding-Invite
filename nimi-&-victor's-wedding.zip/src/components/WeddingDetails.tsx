import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Calendar, Clock, Wine, Sparkles, Navigation } from 'lucide-react';

interface WeddingDetailsProps {
  isDark: boolean;
}

export default function WeddingDetails({ isDark }: WeddingDetailsProps) {
  return (
    <div id="details" className="relative py-24 px-4 bg-bloom-cream/40 dark:bg-dark-garden/20 overflow-hidden">
      {/* Delicate horizontal floral vines dividing sections */}
      <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-bloom-gold/20 to-transparent"></div>

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="font-cinzel text-bloom-gold text-xs tracking-[0.3em] uppercase block mb-3">
            The Celebration
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-bloom-charcoal dark:text-bloom-cream italic font-light">
            Wedding Details
          </h2>
          <div className="w-12 h-[1px] bg-bloom-gold/40 mx-auto mt-4"></div>
        </motion.div>

        {/* DETAILS SUITE (CARDS) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          
          {/* CARD 1: WHITE WEDDING */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -6 }}
            transition={{ duration: 0.6 }}
            className="bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 p-8 rounded-3xl shadow-md paper-texture flex flex-col justify-between h-full group"
          >
            <div>
              {/* Card Header Illustration */}
              <div className="flex justify-between items-center mb-6">
                <span className="font-cinzel text-[10px] text-bloom-gold tracking-widest uppercase">
                  Part One
                </span>
                <Sparkles className="w-4 h-4 text-bloom-rose opacity-40 group-hover:opacity-100 transition-opacity" />
              </div>

              {/* Title */}
              <h3 className="font-serif text-2xl text-bloom-charcoal dark:text-bloom-cream font-medium mb-4">
                White Wedding
              </h3>

              {/* Gold Divider Line */}
              <div className="w-full h-[1px] bg-gradient-to-r from-bloom-gold/30 via-bloom-gold/10 to-transparent my-4"></div>

              {/* Timing */}
              <div className="space-y-3 font-serif text-sm text-bloom-charcoal/80 dark:text-bloom-cream/80 mb-6">
                <div className="flex items-center gap-2.5">
                  <Calendar className="w-4 h-4 text-bloom-sage" />
                  <span>Wednesday, 12th August 2026</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-bloom-sage" />
                  <span>8:00 AM GMT</span>
                </div>
              </div>

              {/* Location details */}
              <div className="space-y-2 mb-6">
                <div className="flex items-start gap-2.5 text-left">
                  <MapPin className="w-4 h-4 text-bloom-rose mt-1 shrink-0" />
                  <div>
                    <h4 className="font-serif text-sm font-medium text-bloom-charcoal dark:text-bloom-cream">
                      The Secret Garden Glasshouse
                    </h4>
                    <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/70">
                      Weeping Willow Lane, Kent, UK
                    </p>
                  </div>
                </div>
              </div>

              <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/80 leading-relaxed">
                Join us as we declare our sacred covenant under an ethereal cathedral glass dome filled with blossoms, ferns, and hanging jasmine vines.
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-dashed border-bloom-gold/20 flex justify-between items-center text-xs text-bloom-gold">
              <span className="font-cinzel">Ceremony</span>
              <span className="font-serif italic">Formal Attire</span>
            </div>
          </motion.div>

          {/* CARD 2: TRADITIONAL WEDDING */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -6 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 p-8 rounded-3xl shadow-md paper-texture flex flex-col justify-between h-full group"
          >
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="font-cinzel text-[10px] text-bloom-gold tracking-widest uppercase">
                  Part Two
                </span>
                <Sparkles className="w-4 h-4 text-bloom-gold opacity-40 group-hover:opacity-100 transition-opacity" />
              </div>

              <h3 className="font-serif text-2xl text-bloom-charcoal dark:text-bloom-cream font-medium mb-4">
                Traditional Wedding
              </h3>

              <div className="w-full h-[1px] bg-gradient-to-r from-bloom-gold/30 via-bloom-gold/10 to-transparent my-4"></div>

              <div className="space-y-3 font-serif text-sm text-bloom-charcoal/80 dark:text-bloom-cream/80 mb-6">
                <div className="flex items-center gap-2.5">
                  <Calendar className="w-4 h-4 text-bloom-sage" />
                  <span>Wednesday, 12th August 2026</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-bloom-sage" />
                  <span>12:00 Noon GMT</span>
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <div className="flex items-start gap-2.5 text-left">
                  <MapPin className="w-4 h-4 text-bloom-rose mt-1 shrink-0" />
                  <div>
                    <h4 className="font-serif text-sm font-medium text-bloom-charcoal dark:text-bloom-cream">
                      The Heritage Gardens
                    </h4>
                    <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/70">
                      Weeping Willow Lane, Kent, UK
                    </p>
                  </div>
                </div>
              </div>

              <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/80 leading-relaxed">
                A colorful and vibrant celebration of our rich cultural roots, traditional custom greetings, family blessings, and gorgeous heritage attire.
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-dashed border-bloom-gold/20 flex justify-between items-center text-xs text-bloom-gold">
              <span className="font-cinzel">Tradition</span>
              <span className="font-serif italic">Cultural Attire</span>
            </div>
          </motion.div>

          {/* CARD 3: GRAND RECEPTION */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -6 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-bloom-ivory dark:bg-dark-paper border border-bloom-gold/20 p-8 rounded-3xl shadow-md paper-texture flex flex-col justify-between h-full group"
          >
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="font-cinzel text-[10px] text-bloom-gold tracking-widest uppercase">
                  Part Three
                </span>
                <Wine className="w-4 h-4 text-bloom-rose opacity-40 group-hover:opacity-100 transition-opacity" />
              </div>

              <h3 className="font-serif text-2xl text-bloom-charcoal dark:text-bloom-cream font-medium mb-4">
                Grand Reception
              </h3>

              <div className="w-full h-[1px] bg-gradient-to-r from-bloom-gold/30 via-bloom-gold/10 to-transparent my-4"></div>

              <div className="space-y-3 font-serif text-sm text-bloom-charcoal/80 dark:text-bloom-cream/80 mb-6">
                <div className="flex items-center gap-2.5">
                  <Calendar className="w-4 h-4 text-bloom-sage" />
                  <span>Wednesday, 12th August 2026</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-bloom-sage" />
                  <span>After 3:00 PM GMT</span>
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <div className="flex items-start gap-2.5 text-left">
                  <MapPin className="w-4 h-4 text-bloom-rose mt-1 shrink-0" />
                  <div>
                    <h4 className="font-serif text-sm font-medium text-bloom-charcoal dark:text-bloom-cream">
                      The Conservatory Orchid Hall
                    </h4>
                    <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/70">
                      Weeping Willow Lane, Kent, UK
                    </p>
                  </div>
                </div>
              </div>

              <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/80 leading-relaxed">
                Step into a candlelit forest banquet hall for floral-infused cocktails, wood-fire delicacies, elegant toasts, and twilight dancing beneath the stars.
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-dashed border-bloom-gold/20 flex justify-between items-center text-xs text-bloom-gold">
              <span className="font-cinzel">Banquet</span>
              <span className="font-serif italic">Evening Live Band</span>
            </div>
          </motion.div>

        </div>

        {/* Guest Accommodations Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 bg-bloom-ivory/80 dark:bg-dark-paper/80 border border-bloom-gold/15 p-8 rounded-3xl text-center max-w-3xl mx-auto backdrop-blur-xs paper-texture"
        >
          <h4 className="font-serif text-xl text-bloom-charcoal dark:text-bloom-cream font-medium mb-2">
            Guest Accommodations &amp; Shuttles
          </h4>
          <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/80 mb-6 leading-relaxed">
            Complementary group shuttle coaches will depart from Rosewood Country Manor starting at 7:15 AM and return passengers periodically after 9:30 PM.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left border-t border-dashed border-bloom-gold/10 pt-6">
            <div>
              <h5 className="font-serif text-sm font-semibold text-bloom-gold uppercase tracking-wider mb-1">
                1. The Rosewood Country Manor
              </h5>
              <p className="font-serif text-xs text-bloom-charcoal/80 dark:text-bloom-cream/80">
                A beautiful boutique hotel 10 minutes from the venue. <br />
                <span className="italic text-bloom-sage-dark dark:text-bloom-sage/70">Special Rate Code: NIMIANDVICTOR</span>
              </p>
            </div>
            <div>
              <h5 className="font-serif text-sm font-semibold text-bloom-gold uppercase tracking-wider mb-1">
                2. Seedling Inn &amp; Cottages
              </h5>
              <p className="font-serif text-xs text-bloom-charcoal/80 dark:text-bloom-cream/80">
                Charming countryside cabins surrounding Kent Lake. <br />
                <span className="italic text-bloom-sage-dark dark:text-bloom-sage/70">Family-friendly countryside lodging.</span>
              </p>
            </div>
          </div>
        </motion.div>

        </div>
      </div>
  );
}
