import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Sun, Moon, Heart } from 'lucide-react';

interface NavbarProps {
  isDark: boolean;
  setIsDark: (val: boolean) => void;
}

export default function Navbar({ isDark, setIsDark }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Smooth scroll helper
  const scrollTo = (id: string) => {
    setIsOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Set initial dark theme on load if selected
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const navItems = [
    { label: 'Invitation', id: 'invitation' },
    { label: 'Our Story', id: 'story' },
    { label: 'Details', id: 'details' },
    { label: 'Registry', id: 'registry' },
    { label: 'Love Notes', id: 'notes' },
    { label: 'RSVP', id: 'rsvp' },
  ];

  return (
    <>
      <motion.nav
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className={`fixed top-0 inset-x-0 z-40 transition-all duration-500 ${
          scrolled
            ? 'bg-bloom-ivory/80 dark:bg-dark-garden/80 backdrop-blur-md py-4 shadow-sm border-b border-bloom-gold/10'
            : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          {/* Logo Monogram */}
          <div
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-1.5 cursor-pointer select-none group"
          >
            <span className="font-cinzel text-base tracking-[0.2em] text-bloom-charcoal dark:text-bloom-cream group-hover:text-bloom-rose transition-colors">
              V
            </span>
            <Heart className="w-2.5 h-2.5 text-bloom-rose fill-currentColor opacity-50 group-hover:opacity-100 transition-opacity" />
            <span className="font-cinzel text-base tracking-[0.2em] text-bloom-charcoal dark:text-bloom-cream group-hover:text-bloom-rose transition-colors">
              N
            </span>
          </div>

          {/* Desktop Navigation links */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="font-cinzel text-[10px] tracking-[0.2em] uppercase text-bloom-charcoal/80 dark:text-bloom-cream/80 hover:text-bloom-rose dark:hover:text-bloom-rose transition-colors relative group py-1 cursor-pointer"
              >
                {item.label}
                <span className="absolute bottom-0 left-1/2 w-0 h-[1px] bg-bloom-rose transition-all group-hover:w-full group-hover:left-0"></span>
              </button>
            ))}
          </div>

          {/* Utilities: Dark Mode Toggle & Mobile Menu Toggle */}
          <div className="flex items-center gap-4">
            {/* Dark Mode Toggle */}
            <motion.button
              id="theme-toggle-btn"
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsDark(!isDark)}
              className="p-2 rounded-full text-bloom-charcoal/80 dark:text-bloom-cream/80 hover:bg-bloom-sage/10 transition-colors cursor-pointer"
              title="Toggle theme"
            >
              {isDark ? <Sun className="w-4 h-4 text-bloom-gold-light" /> : <Moon className="w-4 h-4 text-bloom-sage-dark" />}
            </motion.button>

            {/* Mobile Menu Icon */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 text-bloom-charcoal/80 dark:text-bloom-cream/80 hover:bg-bloom-sage/10 transition-colors cursor-pointer"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* MOBILE DRAWER */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-x-0 top-[60px] z-30 bg-bloom-ivory dark:bg-dark-paper border-b border-bloom-gold/15 p-6 shadow-xl flex flex-col md:hidden items-center text-center space-y-6 select-none paper-texture"
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="font-cinzel text-xs tracking-[0.2em] uppercase text-bloom-charcoal dark:text-bloom-cream hover:text-bloom-rose block cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
