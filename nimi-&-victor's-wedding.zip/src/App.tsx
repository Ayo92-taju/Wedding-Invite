import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import OpeningExperience from './components/OpeningExperience';
import CursorFlower from './components/CursorFlower';
import InvitationCard from './components/InvitationCard';
import LoveStory from './components/LoveStory';
import WeddingDetails from './components/WeddingDetails';
import GiftRegistry from './components/GiftRegistry';
import CountdownTimer from './components/CountdownTimer';
import LoveNotes from './components/LoveNotes';
import RsvpSection from './components/RsvpSection';
import { Heart, Navigation } from 'lucide-react';
import watercolorBg from './assets/images/wedding_watercolor_florals_1782892415419.jpg';

export default function App() {
  const [isIntroComplete, setIsIntroComplete] = useState(false);
  const [isDark, setIsDark] = useState(false);

  // Fallback image in case the generated one fails to resolve, keeping code robust
  const bgImg = watercolorBg || "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?q=80&w=1000&auto=format&fit=crop";

  return (
    <div className={`min-h-screen transition-colors duration-1000 ${
      isDark ? 'bg-dark-garden text-bloom-cream dark' : 'bg-bloom-cream text-bloom-charcoal'
    }`}>
      
      {/* Intro Cinematics */}
      <AnimatePresence>
        {!isIntroComplete && (
          <OpeningExperience
            isDark={isDark}
            onComplete={() => setIsIntroComplete(true)}
          />
        )}
      </AnimatePresence>

      {/* Main App Content - Fades in once intro is complete */}
      {isIntroComplete && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2 }}
          className="relative"
        >
          {/* Subtle Ambient Drifting Elements */}
          <CursorFlower />

          {/* Luxury Navigation Bar */}
          <Navbar isDark={isDark} setIsDark={setIsDark} />

          {/* ROMANTIC HERO BANNER */}
          <header className="relative min-h-screen flex items-center justify-center overflow-hidden py-32 px-6">
            {/* Soft decorative background illustration */}
            <div className="absolute inset-0 w-full h-full opacity-10 dark:opacity-[0.06] select-none pointer-events-none">
              <img
                src={bgImg}
                alt="Watercolour botanicals background"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Subtle radial shadow depth layer */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,rgba(252,249,242,0.45)_90%)] dark:bg-[radial-gradient(circle_at_center,transparent_20%,rgba(17,27,21,0.6)_95%)] pointer-events-none"></div>

            {/* Inner Gold Foil Frame Panel */}
            <div className="max-w-4xl w-full border border-bloom-gold/15 dark:border-bloom-gold/10 p-8 md:p-16 rounded-[40px] text-center relative z-10 paper-texture shadow-xs">
              <div className="absolute inset-3 border border-bloom-gold/30 rounded-[28px] pointer-events-none opacity-80"></div>
              
              {/* Elegant central line graphics */}
              <div className="mb-6 flex items-center justify-center gap-2 text-bloom-gold">
                <div className="w-10 h-[1px] bg-bloom-gold/40"></div>
                <Heart className="w-3.5 h-3.5 fill-currentColor" />
                <div className="w-10 h-[1px] bg-bloom-gold/40"></div>
              </div>

              {/* Title Header */}
              <motion.span
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 0.8, y: 0 }}
                transition={{ duration: 1, delay: 0.2 }}
                className="font-cinzel text-[10px] md:text-xs tracking-[0.4em] uppercase block mb-4 text-bloom-gold"
              >
                Welcome to the Wedding of
              </motion.span>

              {/* Cursive Romantic Couple Names */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.5, delay: 0.4, ease: 'easeOut' }}
                className="space-y-2 md:space-y-4"
              >
                <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-extralight tracking-tight text-bloom-charcoal dark:text-bloom-cream">
                  Victor &amp; Nimi
                </h1>
                
                <h2 className="font-script text-4xl md:text-5xl text-bloom-rose mt-2 tracking-wide">
                  Love in Full Bloom
                </h2>
              </motion.div>

              <div className="w-16 h-[1px] bg-bloom-gold/40 mx-auto my-8"></div>

              {/* Ceremony Context */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.6 }}
                className="space-y-3 font-serif text-sm md:text-base text-bloom-sage-dark dark:text-bloom-sage max-w-lg mx-auto"
              >
                <p className="tracking-widest uppercase text-xs text-bloom-gold font-light">
                  Wednesday, August 12, 2026
                </p>
                <p className="italic font-light">
                  The Secret Garden Glasshouse, Kentish Woodlands, UK
                </p>
              </motion.div>

              {/* Love Quote Footnote */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.7 }}
                transition={{ duration: 1.5, delay: 0.8 }}
                className="border-t border-dashed border-bloom-gold/15 pt-8 mt-10 max-w-sm mx-auto"
              >
                <p className="font-serif italic text-xs leading-relaxed text-bloom-sage-dark dark:text-bloom-sage/70">
                  &ldquo;Love grows gently, intentionally, and beautifully over time&mdash;like a garden nurtured with care.&rdquo;
                </p>
              </motion.div>

              {/* Scroll Call to Action */}
              <motion.button
                id="view-invitation-btn"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  const el = document.getElementById('invitation');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="mt-12 px-8 py-3.5 bg-bloom-gold text-bloom-ivory font-cinzel text-[10px] tracking-widest uppercase rounded-full shadow-md hover:shadow-lg transition-all duration-300 flex items-center gap-2 mx-auto cursor-pointer"
              >
                <Navigation className="w-3 h-3 rotate-45" />
                Unfold Invitation
              </motion.button>
            </div>
          </header>

          {/* INVITATION MODULE */}
          <section className="relative">
            <InvitationCard isDark={isDark} />
          </section>

          {/* LIVE TIMER COUNTDOWN */}
          <section className="relative">
            <CountdownTimer isDark={isDark} />
          </section>

          {/* LOVE STORY SCROLL-GARDEN TIMELINE */}
          <section className="relative bg-bloom-cream/20 dark:bg-dark-garden/10">
            <LoveStory isDark={isDark} />
          </section>

          {/* CELEBRATION CARDS DETAILS */}
          <section className="relative">
            <WeddingDetails isDark={isDark} />
          </section>

          {/* GARDEN OF GIFTS REGISTRY */}
          <section className="relative bg-bloom-cream/20 dark:bg-dark-garden/10">
            <GiftRegistry isDark={isDark} />
          </section>

          {/* LOVE NOTES WALL Q&A */}
          <section className="relative">
            <LoveNotes isDark={isDark} />
          </section>

          {/* RSVP CONFIRMATION RITUAL */}
          <section className="relative bg-bloom-cream/10">
            <RsvpSection isDark={isDark} />
          </section>

          {/* LUXURY EDITORIAL FOOTER */}
          <footer className="relative py-16 px-6 text-center border-t border-bloom-gold/20 bg-bloom-ivory dark:bg-dark-paper paper-texture select-none">
            <div className="max-w-md mx-auto space-y-6">
              
              <div className="font-script text-4xl text-bloom-rose">
                Victor &amp; Nimi
              </div>

              <div className="w-12 h-[1px] bg-bloom-gold/40 mx-auto"></div>

              <p className="font-serif italic text-xs text-bloom-sage-dark dark:text-bloom-sage/70 leading-relaxed">
                Thank you for being part of our story. We can&apos;t wait to celebrate our love blooming with you.
              </p>

              <div className="space-y-1">
                <p className="font-cinzel text-[9px] tracking-[0.3em] uppercase text-bloom-gold">
                  #NIMIANDVICTOR26
                </p>
                <p className="font-serif text-[10px] text-bloom-sage-dark dark:text-bloom-sage/50">
                  Kent, United Kingdom &bull; All Rights Reserved
                </p>
              </div>

            </div>
          </footer>

        </motion.div>
      )}

    </div>
  );
}
